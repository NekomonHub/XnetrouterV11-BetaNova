global.turn = true
global.udp = true
